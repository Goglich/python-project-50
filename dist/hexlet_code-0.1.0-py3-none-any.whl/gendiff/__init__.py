from gendiff.module.gendiff import generate_diff as generate_diff


__all__ = (
    generate_diff
)
