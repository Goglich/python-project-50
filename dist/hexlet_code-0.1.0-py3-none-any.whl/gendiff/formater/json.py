import json


def make_json(data):
    return json.dumps(data, indent=4)
