def generate_diff(file1, file2):
    print('i am working!')